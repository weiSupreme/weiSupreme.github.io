clear;close all;clc;
addpath(genpath('.'));

for k=5:5
    %img_folder = 'period16_c0';
    %img_folder=sprintf('period14_camera%d_annotated',k);%_annotated����
    %img_folder=sprintf('period14_camera%d_src',k);%_src����
    %img_folder=sprintf('period14_camera%d_syn',k);%_syn����
    
    img = dir('*.png');
    first_frame = datenum([2008 04 09 18 39 43]);
    last_frame = datenum([2008 04 09 18 41 07]);
    frame_step = 1/(24*60*60);
    j = 0;
    for frame_idx = first_frame:frame_step:last_frame
        for i = 1:22
            %old_name = ['camera1_' datestr(frame_idx,'yyyymmddTHHMMSS+02') '_frame' num2str(i) '.png']; 
            strTemp1=sprintf('camera%d_',k);
            old_name = [strTemp1 datestr(frame_idx,'yyyymmddTHHMMSS+02') '_frame' num2str(i) '_annotated' '.png'];
            %old_name=['period14_camera1_frame' num2str(i+j*22) '.png_syn.png'];
            
            if exist(old_name,'file')
                %new_name = ['period16_source-c0-f' num2str(i+j*22) '.png'];
                strTemp2=sprintf('period14_camera%d_frame',k);%_src����
                new_name = [num2str(1870+i+j*22) '.png'];
                
                %new_name=[strTemp1 datestr(frame_idx,'yyyymmddTHHMMSS+02') '_frame' num2str(i) '_annotated.png'];%_annotated����

                %new_name=['period14_camera1_frame' num2str(i+j*22) '_syn.png'];%_syn����
                
                eval(['!rename' 32 old_name 32 new_name]);
            else
                continue;
            end
        end
        j = j + 1;
    end
end