# CarNumRecognize
recognize car license numbers from car image

car numbers image dataset is charSamples.zip, and these images are grayscale images.
